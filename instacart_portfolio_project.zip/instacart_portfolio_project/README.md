# Instacart Customer Retention & Reorder Behavior Analysis

**End-to-end product/data analytics project** — from raw transactional data to an executive dashboard and business recommendations. Built to mirror how a real analytics engagement runs: a business problem first, a database second, and a stakeholder-facing deliverable last.

📊 **[View the Power BI Dashboard](#dashboard)** · 📄 **[Read the Full Insights Report](docs/Insights_and_Recommendations.docx)** · 👤 **[LinkedIn](https://linkedin.com/in/YOUR-LINKEDIN-HERE)** · 💻 **[GitHub](https://github.com/YOUR-USERNAME-HERE)**

---

## Business Problem

> *"Why do some customers keep ordering while others drop off — and which products or behaviors predict long-term retention?"*

Instacart (grocery delivery/pickup) depends on repeat purchases for profitability. Using 3.2M+ historical orders from 206,209 customers, this project identifies **where** retention breaks down, **which** product categories drive loyalty, **how** customers segment behaviorally, and **which** products should be cross-sold together — then turns each finding into a specific, actionable recommendation.

Full business requirements: [`docs/01_business_requirements.md`](docs/01_business_requirements.md)

---

## Tech Stack

| Stage | Tool |
|---|---|
| Data storage & querying | MySQL |
| Analysis & modeling | Python (pandas, scikit-learn, mlxtend) |
| Dashboard | Power BI |
| Documentation | Markdown, Word |

---

## Workflow

```
Raw CSVs (Kaggle)
   │
   ▼
MySQL database (schema + load + data quality checks)
   │
   ▼
SQL exploratory analysis (retention curve, timing, reorder rates by category)
   │
   ▼
Python: customer segmentation (KMeans) + market basket analysis (Apriori)
   │
   ▼
Power BI dashboard (one-page executive view)
   │
   ▼
Insights & Recommendations report
```

---

## Dashboard

![Dashboard Screenshot](assets/dashboard_screenshot.png)

*Built in Power BI — see [`docs/04_powerbi_build_guide.md`](docs/04_powerbi_build_guide.md) for the full build steps, DAX measures, and layout decisions.*

---

## Key Findings

| # | Finding |
|---|---|
| 1 | **Retention cliff at order 3→4**: retention holds at 95–97% between most consecutive orders, but drops sharply from 95.8% → 88.6% at this specific point — the single steepest fall in the entire customer lifecycle. |
| 2 | **Category loyalty gap**: dairy & eggs leads reorder rate at 67%; the lowest-performing departments sit ~9 points behind. |
| 3 | **Four behavioral segments** emerge from clustering on order frequency, basket size, and reorder rate — from Power Loyalists (~38% of customers) to Dormant/Occasional shoppers. |
| 4 | **Predictable ordering rhythm**: a ~7-day median gap between orders, with clear day/hour concentration — useful for reminder timing and staffing. |
| 5 | **Cross-sell signal**: product pairs like organic garlic ↔ organic yellow onion show 3.35x lift over chance — a concrete bundling opportunity. |

Full findings, recommendations, and expected impact: [`docs/Insights_and_Recommendations.docx`](docs/Insights_and_Recommendations.docx)

---

## Data Limitations (disclosed up front, not hidden)

- No revenue, pricing, or demographic data exists in this dataset — all impact framing is behavioral/directional, not dollarized.
- Every customer already has 4+ historical orders (Instacart's own export filter) — this dataset **cannot** show true first-order churn.
- `days_since_prior_order` is capped at 30 days, understating gaps for lapsed customers.

Full data quality write-up: [`docs/02_data_quality_report.md`](docs/02_data_quality_report.md)

---

## Repo Structure

```
├── docs/                Business requirements, data quality report, metrics dictionary,
│                        Power BI build guide, final insights report
├── sql/                 Schema, data load, data quality checks, EDA, Phase 4 exports (MySQL)
├── notebooks/           Python scripts — customer segmentation & market basket analysis
├── outputs/             Summary CSVs and charts feeding the dashboard/report
├── dashboard/           Power BI .pbix file
├── assets/              Images used in this README
└── data/                (gitignored — raw CSVs too large for GitHub; see below)
```

## Getting the Data

Raw CSVs are not committed (500MB+, exceeds GitHub's file limits and isn't mine to redistribute). Download the original dataset from Kaggle — ["Instacart Market Basket Analysis"](https://www.kaggle.com/c/instacart-market-basket-analysis/data) — and place the 6 CSVs in `data/` before running `sql/01_schema_mysql.sql` and `sql/02_load_data_mysql.sql`.

## Reproducing This Project

1. `sql/01_schema_mysql.sql` → create the database schema
2. `sql/02_load_data_mysql.sql` → load the CSVs (see in-file notes on `secure_file_priv`)
3. `sql/03_data_quality_checks.sql` → verify data integrity
4. `sql/04_eda_phase3.sql` → run the exploratory analysis queries
5. `sql/05_phase4_exports.sql` → export the two feature tables needed for Python
6. `notebooks/phase4a_customer_segmentation.py` → run customer segmentation
7. `notebooks/phase4b_basket_analysis.py` → run market basket analysis
8. Open `dashboard/instacart_dashboard.pbix` in Power BI, or rebuild using `docs/04_powerbi_build_guide.md`

---

## Author

**[Your Name]** — Aspiring Product/Data Analyst
📧 your.email@example.com · 🔗 [LinkedIn](https://linkedin.com/in/YOUR-LINKEDIN-HERE) · 💻 [Portfolio](https://your-portfolio-site.com)
